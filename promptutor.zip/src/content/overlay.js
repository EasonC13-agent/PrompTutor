// Inject floating toggle overlay into chat interfaces
// Shows collection status and allows quick toggle

(function() {
  'use strict';
  
  // Avoid duplicate injection
  if (document.getElementById('promptutor-overlay')) return;
  
  // Create overlay container
  const overlay = document.createElement('div');
  overlay.id = 'promptutor-overlay';
  overlay.innerHTML = `
    <style>
      #promptutor-overlay {
        position: fixed;
        bottom: 80px;
        right: 20px;
        z-index: 10000;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      }
      #promptutor-toggle {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 8px 12px;
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 20px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        cursor: pointer;
        transition: all 0.2s;
        font-size: 13px;
      }
      #promptutor-toggle:hover {
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      }
      #promptutor-toggle.collecting {
        background: #e8f5e9;
        border-color: #4caf50;
      }
      #promptutor-toggle.not-logged-in {
        background: #fff3e0;
        border-color: #ff9800;
      }
      .cc-indicator {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #9e9e9e;
      }
      .cc-indicator.active {
        background: #4caf50;
        animation: cc-pulse 2s infinite;
      }
      @keyframes cc-pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.5; }
      }
      .cc-label {
        color: #333;
        user-select: none;
      }
      .cc-label.clickable {
        cursor: pointer;
        text-decoration: underline dotted;
      }
      .cc-label.clickable:hover {
        color: #2e7d32;
      }
      .cc-label.analyzing {
        opacity: 0.6;
        pointer-events: none;
      }
      .cc-sync-time {
        font-size: 10px;
        color: #aaa;
        margin-left: 2px;
        white-space: nowrap;
      }
      .cc-switch {
        position: relative;
        width: 36px;
        height: 20px;
      }
      .cc-switch input {
        opacity: 0;
        width: 0;
        height: 0;
      }
      .cc-slider {
        position: absolute;
        cursor: pointer;
        inset: 0;
        background: #ccc;
        border-radius: 20px;
        transition: 0.3s;
      }
      .cc-slider:before {
        position: absolute;
        content: "";
        height: 14px;
        width: 14px;
        left: 3px;
        bottom: 3px;
        background: white;
        border-radius: 50%;
        transition: 0.3s;
      }
      input:checked + .cc-slider {
        background: #4caf50;
      }
      input:checked + .cc-slider:before {
        transform: translateX(16px);
      }
      .cc-minimize {
        position: absolute;
        top: -8px;
        right: -8px;
        width: 20px;
        height: 20px;
        background: #666;
        color: white;
        border: none;
        border-radius: 50%;
        cursor: pointer;
        font-size: 12px;
        line-height: 1;
        display: none;
      }
      #promptutor-toggle:hover .cc-minimize {
        display: block;
      }
      #promptutor-overlay.minimized #promptutor-toggle {
        padding: 6px 10px;
      }
      #promptutor-overlay.minimized .cc-label,
      #promptutor-overlay.minimized .cc-switch {
        display: none;
      }
    </style>
    <div id="promptutor-toggle">
      <button class="cc-minimize" title="Minimize">−</button>
      <span class="cc-indicator"></span>
      <span class="cc-label">Share Data</span>
      <span class="cc-sync-time" id="cc-sync-time"></span>
      <label class="cc-switch">
        <input type="checkbox" id="cc-enabled">
        <span class="cc-slider"></span>
      </label>
    </div>
  `;
  
  document.body.appendChild(overlay);
  
  // Elements
  const toggle = document.getElementById('promptutor-toggle');
  const indicator = toggle.querySelector('.cc-indicator');
  const label = toggle.querySelector('.cc-label');
  const syncTimeEl = document.getElementById('cc-sync-time');
  const checkbox = document.getElementById('cc-enabled');
  const minimizeBtn = toggle.querySelector('.cc-minimize');
  
  // State
  let isLoggedIn = false;
  let isEnabled = false;
  let currentMode = 'collect';
  
  // Load state from storage
  async function loadState() {
    const stored = await chrome.storage.local.get(['user', 'enabled', 'mode']);
    isLoggedIn = !!stored.user;
    isEnabled = stored.enabled || false;
    currentMode = stored.mode || 'collect';
    updateUI();
  }
  
  // Update UI based on state
  function updateUI() {
    if (!isLoggedIn) {
      toggle.className = 'not-logged-in';
      indicator.className = 'cc-indicator';
      label.textContent = 'Not signed in';
      checkbox.checked = false;
      checkbox.disabled = true;
    } else {
      toggle.className = isEnabled ? 'collecting' : '';
      indicator.className = isEnabled ? 'cc-indicator active' : 'cc-indicator';
      label.textContent = isEnabled ? (currentMode === 'guidance' ? 'Collecting + Guidance' : 'Collecting') : 'Share Data';
      // Hidden feature: clicking label in guidance mode triggers analysis (no visual hint)
      checkbox.checked = isEnabled;
      checkbox.disabled = false;
    }
  }
  
  // Toggle handler
  checkbox.addEventListener('change', async (e) => {
    if (!isLoggedIn) {
      e.preventDefault();
      checkbox.checked = false;
      // Open extension popup
      alert('Please sign in to PrompTutor first by clicking the extension icon.');
      return;
    }
    
    isEnabled = checkbox.checked;
    await chrome.storage.local.set({ enabled: isEnabled });
    chrome.runtime.sendMessage({ type: 'TOGGLE_ENABLED', enabled: isEnabled });
    updateUI();
  });
  
  // Click on label to trigger guidance analysis
  label.addEventListener('click', async (e) => {
    e.stopPropagation();
    if (!isLoggedIn) {
      alert('Please sign in to PrompTutor first by clicking the extension icon in your browser toolbar.');
      return;
    }
    if (!isEnabled || currentMode !== 'guidance') return;
    if (typeof window.ccAnalyzeAndGuide === 'function') {
      label.classList.add('analyzing');
      label.textContent = 'Analyzing...';
      await window.ccAnalyzeAndGuide(true);
      label.classList.remove('analyzing');
      updateUI();
    }
  });

  // Click on overlay when not logged in
  toggle.addEventListener('click', (e) => {
    if (!isLoggedIn && e.target !== checkbox) {
      alert('Please sign in to PrompTutor first by clicking the extension icon in your browser toolbar.');
    }
  });
  
  // Minimize button
  minimizeBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    overlay.classList.toggle('minimized');
  });
  
  // Listen for storage changes
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.enabled) isEnabled = changes.enabled.newValue;
    if (changes.user) isLoggedIn = !!changes.user.newValue;
    if (changes.accessToken) isLoggedIn = isLoggedIn && !!changes.accessToken.newValue;
    if (changes.mode) currentMode = changes.mode.newValue || 'collect';
    if (changes.enabled || changes.user || changes.accessToken || changes.mode) updateUI();
  });
  
  // Sync timer
  async function updateSyncTimer() {
    if (!syncTimeEl) return;
    try {
      const alarm = await chrome.alarms.get('sync');
      if (!alarm) { syncTimeEl.textContent = ''; return; }
      const secLeft = Math.max(0, Math.round((alarm.scheduledTime - Date.now()) / 1000));
      if (secLeft < 60) {
        syncTimeEl.textContent = '(<1m)';
      } else {
        syncTimeEl.textContent = `(${Math.ceil(secLeft / 60)}m)`;
      }
    } catch (e) {
      syncTimeEl.textContent = '';
    }
  }

  updateSyncTimer();
  setInterval(updateSyncTimer, 30000);

  // Initial load
  loadState();
  
  console.log('[PrompTutor] Overlay injected');
})();
